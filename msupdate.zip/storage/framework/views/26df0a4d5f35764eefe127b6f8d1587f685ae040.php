


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-6">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Enter New Daily Expense Record</h4>
                <form action="<?php echo e(route('expense.update',[$expense->id])); ?>" method="POST" class="needs-validation">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="validationCustom01" class="form-label">Name</label>
                                <input type="text" class="form-control" id="validationCustom01"
                                    placeholder="Name" value="<?php echo e($expense->name); ?>" name="name" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="validationCustom02" class="form-label">Enter Amount</label>
                                <input type="text" class="form-control" id="validationCustom02"
                                    placeholder="amount" value="<?php echo e($expense->amount); ?>" name="amount" >
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="validationCustom03" class="form-label">Category</label>
                                <select class="form-select" id="validationCustom03"  name="category" >
                                    <option selected disabled value="">Choose...</option>
                                    <option <?php if($expense->category=="Inventory Stock"): ?>
                                        selected
                                    <?php endif; ?>>Inventory Stock</option>
                                    <option <?php if($expense->category=="Salery"): ?>
                                        selected
                                    <?php endif; ?>>Salery</option>
                                    <option <?php if($expense->category=="Transport"): ?>
                                        selected
                                    <?php endif; ?>>Transport</option>
                                    <option <?php if($expense->category=="Others"): ?>
                                        selected
                                    <?php endif; ?>>Others</option>
                                </select>
                                <div class="invalid-feedback">
                                    Please select a valid state.
                                </div>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="validationCustom03" class="form-label">Account Type</label>
                                <select class="form-select" id="validationCustom03" value="<?php echo e($expense->account); ?>" name="account" required>
                                    <option selected disabled value="">Choose...</option>
                                    <option <?php if($expense->account=="Cash"): ?>
                                        selected
                                    <?php endif; ?> >Cash</option>
                                    <option <?php if($expense->account=="Cheque"): ?>
                                        selected
                                    <?php endif; ?>>Cheque</option>
                                    <option <?php if($expense->account=="Online"): ?>
                                        selected
                                    <?php endif; ?>>Online</option>
                                    <option <?php if($expense->account=="Others"): ?>
                                        selected
                                    <?php endif; ?>>Others</option>
                                </select>
                                <div class="invalid-feedback">
                                    Please select a valid state.
                                </div>

                            </div>
                        </div>


                    </div>
                    <div class="mb-3">
                        <label>Description</label>
                        <div>
                            <textarea  class="form-control" value="<?php echo e($expense->description); ?>" name="description"></textarea>
                        </div>
                    </div>
                    <div>
                        <button class="btn btn-primary" type="submit">Submit form</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- end card -->
    </div> <!-- end col -->


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Creator\Documents\GitHub\printers\resources\views/backend/pages/ledger/edit.blade.php ENDPATH**/ ?>