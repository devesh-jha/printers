


<?php $__env->startSection('content'); ?>
<div class="col-xl-6">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Enter New Salery Details</h4>

            <form action="<?php echo e(route('empsalary.store')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="card-title">Add New Salery Record</h4>
                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label">Select Employee</label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" placeholder="Select employee" name="employee_id">
                                            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </select>
                                    </div>
                                </div>



                                <div class="row mb-3">
                                    <label for="example-number-input" class="col-sm-2 col-form-label">Amount</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" type="number"  id="example-number-input" name="amount">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="example-number-input" class="col-sm-2 col-form-label" >Description</label>
                                    <div class="col-sm-10">
                                        <div>
                                            <textarea required class="form-control" rows="5" name="description"></textarea>
                                        </div>
                                    </div>
                                </div>









                            </div>
                        </div>
                    </div> <!-- end col -->
                </div>

                <div>

                    <button class="btn btn-primary" type="submit">Submit form</button>
                </div>
            </form>
        </div>
    </div>
    <!-- end card -->
</div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>




<!-- end row -->

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Creator\Documents\GitHub\printers\resources\views/backend/pages/empsalary/create.blade.php ENDPATH**/ ?>