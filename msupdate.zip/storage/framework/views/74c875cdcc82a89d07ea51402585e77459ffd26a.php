


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Enter New Record</h4>
                <form action="<?php echo e(route('ledger.store')); ?>" method="POST" class="needs-validation">
                    <?php echo csrf_field(); ?>
                    
                            <div class="mb-3">
                            <label for="example-date-input" class="form-label">Date</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="date" name="date"  id="example-date-input">
                                </div>
                               
                            </div>


                            <div class="row mb-3">
                                    <label class="form-label">Select Vendor</label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" placeholder="Select employee" name="vendor_id">
                                            <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </select>
                                    </div>
                                </div>









                            <!-- <div class="mb-3">
                                <label for="validationCustom01" class="form-label">Name</label>
                                <input type="text" class="form-control" id="validationCustom01"
                                    placeholder="Name" name="name" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div> -->
                            <div class="mb-3">
                                <label for="validationCustom01" class="form-label">Particulars</label>
                                <input type="text" class="form-control" id="validationCustom01"
                                    placeholder="Particulars" name="particulars" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="validationCustom01" class="form-label">Credit</label>
                                <input type="text" class="form-control" id="validationCustom01"
                                    placeholder="Credit" name="credit" >
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="validationCustom01" class="form-label">Debit</label>
                                <input type="text" class="form-control" id="validationCustom01"
                                    placeholder="Debit" name="debit">
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                
                    <div>
                        <button class="btn btn-primary" type="submit">Submit form</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- end card -->
    </div> <!-- end col -->


</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Creator\Documents\GitHub\printers\resources\views/backend/pages/ledger/create.blade.php ENDPATH**/ ?>