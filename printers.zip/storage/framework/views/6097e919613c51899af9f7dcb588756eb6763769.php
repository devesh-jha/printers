<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Enter New Daily Expense Record</h4>
                <form action="<?php echo e(route('income.store')); ?>" method="POST" class="needs-validation">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="validationCustom01" class="form-label">Name</label>
                                <input type="text" class="form-control" id="validationCustom01"
                                    placeholder="Name" name="name" required>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="validationCustom02" class="form-label">Enter Amount</label>
                                <input type="number" class="form-control" name="amount"
                                parsley-type="email" placeholder="Enter Total amount"/>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="validationCustom03" class="form-label">Category</label>
                                <select class="form-select" id="validationCustom03" name="category" required>
                                    <option selected disabled value="">Choose...</option>
                                    <option>Kachra Wala</option>
                                    <option>Sales</option>
                                    <option>Transport</option>
                                    <option>Others</option>
                                </select>
                                <div class="invalid-feedback">
                                    Please select a valid state.
                                </div>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="validationCustom03" class="form-label">Account Type</label>
                                <select class="form-select" id="validationCustom03" name="account" required>
                                    <option selected disabled value="">Choose...</option>
                                    <option>Cash</option>
                                    <option>Cheque</option>
                                    <option>Online</option>
                                    <option>Others</option>
                                </select>
                                <div class="invalid-feedback">
                                    Please select a valid state.
                                </div>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="row mb-3">
                                <label for="example-date-input" class="form-label">Date</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="date" name="date"  id="example-date-input">
                                </div>
                            </div>

                        </div>


                    </div>
                    <div class="mb-3">
                        <label>Description</label>
                        <div>
                            <textarea required class="form-control" name="description"></textarea>
                        </div>
                    </div>
                    <div>
                        <button class="btn btn-primary" type="submit">Submit form</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- end card -->
    </div> <!-- end col -->


</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\printers\resources\views/backend/pages/income/create.blade.php ENDPATH**/ ?>