<?php $__env->startSection('content'); ?>
<div class="col-xl-6">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Enter New product Details</h4>

            <form action="<?php echo e(route('product.update',[$product->id])); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="mb-3 position-relative">
                            <label for="validationTooltip01" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="validationTooltip01"
                                placeholder="First name" name="name" value="<?php echo e($product->name); ?>" required>
                            <div class="valid-tooltip">
                                Looks good!
                            </div>
                        </div>
                    </div>


                </div>

                <div>

                    <button class="btn btn-primary" type="submit">Submit form</button>
                </div>
            </form>
        </div>
    </div>
    <!-- end card -->
</div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\printer\resources\views/backend/pages/product/edit.blade.php ENDPATH**/ ?>